Topology used: euro28
Algorithm: AMRA
Traffic Generator: No backup	

Erlang Values:
Erlang_1: 300
Erlang_2: 400
Erlang_3: 500
Erlang_4: 600
Erlang_5: 700
Erlang_6: 1000

Seed Values:

Seed_1:	 621	
Seed_2:  1798
Seed_3:  5659
Seed_4:  9528
Seed_5:  1823
Seed_6:  803
Seed_7:  577
Seed_8:  66
Seed_9:  12
Seed_10: 42

Alpha: 0.0
Demands Count: 250000
All modulations checked
Best Paths: 10
Modulation Metric: Dynamic
Regenerators Metric Value: 5
Regenerators Metric: Static 